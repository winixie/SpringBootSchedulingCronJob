// readme-cxie.txt
// 2024-01-05

https://riteshshergill.medium.com/dynamic-task-scheduling-with-spring-boot-6197e66fec42


  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::                (v3.2.0)

2024-01-04T23:24:18.194-05:00  INFO 39940 --- [           main] c.e.s.SpringBootSchedulingApplication    : Starting SpringBootSchedulingApplication using Java 17.0.5 with PID 39940 (C:\HOME\3-Spring\3-SpringBoot\GetStarted\target\classes started by winix in C:\HOME\3-Spring\3-SpringBoot\GetStarted)
2024-01-04T23:24:18.202-05:00  INFO 39940 --- [           main] c.e.s.SpringBootSchedulingApplication    : No active profile set, falling back to 1 default profile: "default"
2024-01-04T23:24:19.263-05:00  INFO 39940 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port 8080 (http)
2024-01-04T23:24:19.272-05:00  INFO 39940 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
2024-01-04T23:24:19.272-05:00  INFO 39940 --- [           main] o.apache.catalina.core.StandardEngine    : Starting Servlet engine: [Apache Tomcat/10.1.16]
2024-01-04T23:24:19.329-05:00  INFO 39940 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2024-01-04T23:24:19.329-05:00  INFO 39940 --- [           main] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 1085 ms
2024-01-04T23:24:19.943-05:00  INFO 39940 --- [           main] o.s.b.a.e.web.EndpointLinksResolver      : Exposing 1 endpoint(s) beneath base path '/actuator'
2024-01-04T23:24:20.097-05:00  INFO 39940 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port 8080 (http) with context path ''
2024-01-04T23:24:20.117-05:00  INFO 39940 --- [           main] c.e.s.SpringBootSchedulingApplication    : Started SpringBootSchedulingApplication in 2.246 seconds (process running for 2.561)
2024-01-04T23:24:30.556-05:00  INFO 39940 --- [nio-8080-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
2024-01-04T23:24:30.556-05:00  INFO 39940 --- [nio-8080-exec-2] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2024-01-04T23:24:30.557-05:00  INFO 39940 --- [nio-8080-exec-2] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms
Scheduling task with job id: 312aa57b-6758-4cec-bd8a-623d32a38e94 and cron expression: 0/30 * * * * ?

Thu Jan 04 23:25:00 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:25:00 EST 2024, With Data: Data to be printed

Thu Jan 04 23:25:30 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:25:30 EST 2024, With Data: Data to be printed

Thu Jan 04 23:26:00 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:26:00 EST 2024, With Data: Data to be printed

Thu Jan 04 23:26:30 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:26:30 EST 2024, With Data: Data to be printed

Thu Jan 04 23:27:00 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:27:00 EST 2024, With Data: Data to be printed

Thu Jan 04 23:27:30 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:27:30 EST 2024, With Data: Data to be printed

Thu Jan 04 23:28:00 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:28:00 EST 2024, With Data: Data to be printed

Thu Jan 04 23:28:30 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:28:30 EST 2024, With Data: Data to be printed
2024-01-04T23:28:37.508-05:00  WARN 39940 --- [nio-8080-exec-5] .w.s.m.s.DefaultHandlerExceptionResolver : Resolved [org.springframework.web.HttpRequestMethodNotSupportedException: Request method 'POST' is not supported]

Thu Jan 04 23:29:00 EST 2024, Running action: PrintDataTask
Thu Jan 04 23:29:00 EST 2024, With Data: Data to be printed
